//
//  ZPLInstrumentsPluginController.h
//  Instruments
//
//  Created by Yigitcan Yurtsever on 22.10.2018.
//  Copyright © 2018 Zeplin, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ZPLMSPluginCommand;

@interface ZPLInstrumentsPluginController : NSObject

+ (void)runActionWithDictionary:(NSDictionary *)dictionary command:(NSObject<ZPLMSPluginCommand> *)command;

@end
