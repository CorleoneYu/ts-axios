//
//  Instruments.h
//  Instruments
//
//  Created by Yigitcan Yurtsever on 22.10.2018.
//  Copyright © 2018 Zeplin, Inc. All rights reserved.
//

#import <Cocoa/Cocoa.h>

FOUNDATION_EXPORT double InstrumentsVersionNumber;
FOUNDATION_EXPORT const unsigned char InstrumentsVersionString[];

#import <Instruments/ZPLInstrumentsPluginController.h>
